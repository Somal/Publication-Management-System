#include "dbworker.h"

DBworker::DBworker(QFile*file)
{
    f=file;
    f->seek(0);
    QByteArray ba(f->read(20));
    nodesize=*(int*)ba.mid(0,4).data();
    qint64 length=*(qint64*)ba.mid(8,8).data();
    ba=QByteArray(f->read(length));
    bordersymbol_1=*(QChar*)ba.mid(16,2).constData();
    bordersymbol_2=*(QChar*)ba.mid(18,2).constData();
    QString*s;
    bastr(&ba,s);


}


void DBworker::header_reader(QString*s){
    int i=s->indexOf(bordersymbol_1);

}


qint64 DBworker::stri64(QString str){
    return *(qint64*)str.constData();
}

void DBworker::bastr(QByteArray*ba,QString*result_str){
    result_str=new QString((QChar*)ba->constData(),ba->length()/2);
}
/*
void strba(QString*result_str,QByteArray*ba){

}

qint64 bai64(QByteArray ba){

}

QByteArray bai64(qint64 qi){

}
*/
