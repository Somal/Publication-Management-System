#ifndef NODE_H
#define NODE_H

#include <QVector>

class Node
{
public:
    Node(bool leaf,qint64 nodelink);
    Node(bool leaf,qint64 nodelink,QVector<qint64>*keys,QVector<qint64>*links);

    bool isleaf();
    int count();
    qint64 get(int n);
    qint64 getlink(int n);
    int searchbin(qint64 key,bool*ishere=0);
    qint64 searchnext(qint64 key);
    bool addlink(qint64 link);
    int add(qint64 key,qint64 link); //0-OK,1-not leaf 2-ishere,should create/append array
    void childsplit(qint64 key,qint64 lowerlink,qint64 upperlink);
    void split();
    void deletekey(qint64 key);

    qint64 nodelink;
private:
    bool leaf;
    int cnt;
    QVector<qint64>links;
    QVector<qint64>keys;

};

#endif // NODE_H
