#ifndef DBWORKER_H
#define DBWORKER_H

#include "treeoperator.h"

struct column{
    QString name;
    int type;
    int id;
    int treeid;
};

class table{
public:
    QVector<qint64>treelinks;
    QVector<TreeOperator*>trees;
    QVector<column>columns;
    int cnt;
    qint64 idhashlink;

};



class DBworker
{
public:
    DBworker(QFile*file);
    QFile*f;



    static qint64 stri64(QString str);
    static void bastr(QByteArray*ba,QString*result_str);
//    static void strba(QString*result_str,QByteArray*ba);
//    static qint64 bai64(QByteArray ba);
//    static QByteArray bai64(qint64 qi);
private:
    int nodesize,filepagesize;
    QVector<table>tables;
    void header_reader(QString*s);
    QChar bordersymbol_1,bordersymbol_2;
};

#endif // DBWORKER_H
