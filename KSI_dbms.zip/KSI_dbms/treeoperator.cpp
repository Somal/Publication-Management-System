#include "treeoperator.h"

TreeOperator::TreeOperator(QFile*file,qint64 rootlink,int node_size,int filepagesize)
{
    f=file;
    nodesize=node_size;
    this->filepagesize=filepagesize;
    *root=noderead(rootlink);
}

Node TreeOperator::findNode(qint64 key, QStack<qint64>*stack){
    Node*nd=root;
    qint64 link;
    while(!nd->isleaf()){
        link=nd->searchnext(key);
        stack->push(nd->nodelink);
        *nd=noderead(link);
    }
    return *nd;
}

bool TreeOperator::add(qint64 key,qint64 link){
    QStack<qint64> stack;
    *nd1=findNode(key,&stack);
    nd1->add(key,link);
    if(nd1->count()>nodesize){
        spliting();
        return false;
    }
    nodesave(nd1);
    return true;

}

void TreeOperator::spliting(){
    int cnt=nd1->count();
    QVector<qint64>key,link;
    key.resize((cnt+1)/2);
    key.resize((cnt+1)/2+1);
    int st=cnt/2;
    for(int i=st;i<cnt;i+=1){
        key[i-st]=nd1->get(st);
        link[i-st]=nd1->getlink(st);
    }
    link[cnt-st]=nd1->getlink(cnt);
    nd2=new Node(nd1->isleaf(),0,&key,&link);
    nd1->split();

}

/*
bool TreeOperator::deletekey(qint64 key){

}
*/

Node TreeOperator::noderead(qint64 link){
    f->seek(link);
    QByteArray ba=f->read(filepagesize);
    Node nd(babool(&ba,0),link);
    int cnt=baint(&ba,1),i=5;
    for(int j=0;j<cnt;j+=1,i+=16){
        nd.add(baqint64(&ba,i+8),baqint64(&ba,i));
    }
    nd.addlink(baqint64(&ba,i));
    return nd;
}

void TreeOperator::nodesave(Node*nd){
    QByteArray ba;
    ba.resize(13+16*nd->count());
    bool bl=nd->isleaf();
    ba.replace(0,1,(char*)&bl,1);
    int cnt=nd->count(),i=5;
    ba.replace(1,4,(char*)&cnt,4);
    qint64 tmp;
    for(int j=0;j<cnt;j+=1){
        tmp=nd->getlink(j);
        ba.replace(i,8,(char*)&tmp,8);
        i+=8;
        tmp=nd->get(j);
        ba.replace(i,8,(char*)&tmp,8);
        i+=8;
    }
    tmp=nd->getlink(cnt);
    ba.replace(i,8,(char*)&tmp,8);
}

void TreeOperator::nodesave(Node *node,qint64 nodelink){
    node->nodelink=nodelink;
    nodesave(node);
}

int TreeOperator::baint(QByteArray*ba,int i){
    return *(int*)(ba->mid(i,4).data());
}

bool TreeOperator::babool(QByteArray*ba,int i){
    return *(bool*)(ba->mid(i,1).data());
}

qint64 TreeOperator::baqint64(QByteArray*ba,int i){
    return *(qint64*)(ba->mid(i,8).data());
}
