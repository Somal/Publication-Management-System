#ifndef NETWORKWORER_H
#define NETWORKWORER_H


class networkworer
{
public:
    networkworer();
private:
};

#endif // NETWORKWORER_H
