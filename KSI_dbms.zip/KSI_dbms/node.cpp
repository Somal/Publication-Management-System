#include "node.h"

Node::Node(bool leaf,qint64 nodelink)
{
    this->leaf=leaf;
    this->nodelink=nodelink;
    cnt=0;
}

Node::Node(bool leaf,qint64 nodelink,QVector<qint64>*key,QVector<qint64>*link)
{
    this->nodelink=nodelink;
    cnt=key->count();
    keys.resize(cnt);
    links.resize(cnt+1);
    for(int i=0;i<cnt;i+=1){
        keys[i]=key->at(i);
        links[i]=link->at(i);
    }
    links[cnt]=link->at(cnt);
    this->leaf=leaf;
}

bool Node::isleaf(){
    return leaf;
}

int Node::count(){
    return cnt;
}

qint64 Node::get(int n){
    return keys[n];
}

qint64 Node::getlink(int n){
    return links[n];
}

int Node::searchbin(qint64 key, bool *ishere){
    int left=-1,right=cnt;
    qint64 res;
    while(right-left>1){
        res=key-keys[(left+right)/2];
        if(res>0){
            left=(left+right)/2;
        }else{
            if(res<0){
                right=(left+right)/2;
            }else{
                if(ishere!=0)
                    *ishere=true;
                return (left+right)/2;
            }
        }
    }
    if(ishere!=0)
        *ishere=false;
    return right;
}

qint64 Node::searchnext(qint64 key){
    return getlink(searchbin(key));
}

int Node::add(qint64 key, qint64 link){
    if(leaf){
        bool ishere;
        int i=searchbin(key,&ishere);
        if(ishere){
            return 2;
        }
        keys.insert(i,key);
        links.insert(i,link);
        cnt+=1;
        return 0;
    }
    return 1;
}

bool Node::addlink(qint64 link){
   if(keys.count()==links.count()){
       links.append(link);
       return true;
   }
   return false;
}

void Node::split(){
    cnt/=2;
    keys.resize(cnt);
    links.resize(cnt+1);
}

void Node::childsplit(qint64 key, qint64 lowerlink, qint64 upperlink){
    int i=searchbin(key);
    keys.insert(i,key);
    links[i]=lowerlink;
    links.insert(i+1,upperlink);
}

void Node::deletekey(qint64 key){
    bool ishere;
    int i=searchbin(key,&ishere);
    if(ishere){
        keys.remove(i);
        links.remove(i);
    }
}


