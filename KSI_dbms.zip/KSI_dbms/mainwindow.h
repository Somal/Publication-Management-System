#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QGroupBox>

#include <QGridLayout>
#include <QHBoxLayout>

#include <QPushButton>
#include <QLabel>
#include <QTableWidget>
#include <QListWidget>

#include "dbworker.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();
private:
    QWidget*w;
    QGridLayout*glmain,*gls[4];//queries,logs,db,file
    QGroupBox *gbs[4];//queries,logs,db,file
    QHBoxLayout*hlmain;
    QPushButton*pbexit,*pbopendb,*pbs[4];//queries,logs,db,file
    QLabel*linfo;

    QFile*fpref;
    QFile*fdb;
    int isactive;
private slots:
    void fexit();
    void fopendb();
    void fshowqueries();
    void fshowlogs();
    void fshowdb();
    void fshowfile();
private:
    void floadpref();
    void fsavepref();
};

#endif // MAINWINDOW_H
