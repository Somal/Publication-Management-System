#include "mainwindow.h"
#include <QTextStream>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    fpref=new QFile("main.conf");
    floadpref();

    gbs[0]=new QGroupBox("Queries");
    gbs[0]->setMinimumSize(400,600);
    gbs[1]=new QGroupBox("Logs");
    gbs[1]->setMinimumSize(400,600);
    gbs[1]->hide();
    gbs[2]=new QGroupBox("Database Info");
    gbs[2]->setMinimumSize(400,600);
    gbs[2]->hide();
    gbs[3]=new QGroupBox("File Info");
    gbs[3]->setMinimumSize(400,600);
    gbs[3]->hide();
    isactive=0;

    gls[0]=new QGridLayout;
    gbs[0]->setLayout(gls[0]);
    gls[1]=new QGridLayout;
    gbs[1]->setLayout(gls[1]);
    gls[2]=new QGridLayout;
    gbs[2]->setLayout(gls[2]);
    gls[3]=new QGridLayout;
    gbs[3]->setLayout(gls[3]);

    pbs[0]=new QPushButton("Queries");
    pbs[1]=new QPushButton("Logs");
    pbs[2]=new QPushButton("Database");
    pbs[3]=new QPushButton("File");
    hlmain=new QHBoxLayout;
    pbexit=new QPushButton("Exit");
    linfo=new QLabel("Pick your Database");

    hlmain->addStretch(5);
    hlmain->addWidget(pbs[0]);
    hlmain->addWidget(pbs[1]);
    hlmain->addWidget(pbs[2]);
    hlmain->addWidget(pbs[3]);
    hlmain->addStretch(2);
    hlmain->addWidget(linfo);
    hlmain->addStretch(2);
    hlmain->addWidget(pbexit);
    pbopendb=new QPushButton("Open DB");

    w=new QWidget;
    glmain=new QGridLayout;

    glmain->addWidget(gbs[0],0,0,10,10);
    glmain->addWidget(gbs[1],0,0,10,10);
    glmain->addWidget(gbs[2],0,0,10,10);
    glmain->addWidget(gbs[3],0,0,10,10);
    glmain->addItem(hlmain,10,0,1,10);

    w->setLayout(glmain);
    this->setCentralWidget(w);
    this->setWindowTitle("KSI_dbms v0.1");



    connect(pbs[0],SIGNAL(clicked(bool)),this,SLOT(fshowqueries()));
    connect(pbs[1],SIGNAL(clicked(bool)),this,SLOT(fshowlogs()));
    connect(pbs[2],SIGNAL(clicked(bool)),this,SLOT(fshowdb()));
    connect(pbs[3],SIGNAL(clicked(bool)),this,SLOT(fshowfile()));
}

MainWindow::~MainWindow()
{

}

void MainWindow::fexit(){
    fsavepref();
    this->close();
}

void MainWindow::fopendb(){

}

void MainWindow::floadpref(){
    if(fpref->open(QIODevice::Text|QIODevice::ReadOnly)){
        QString s;
        QTextStream fin(fpref);
        while(!fin.atEnd()){
            s=fin.readLine();
        }
        fpref->close();
    }
}

void MainWindow::fsavepref(){

}

void MainWindow::fshowqueries(){
    if(isactive!=0){
        gbs[isactive]->hide();
        gbs[0]->show();
        isactive=0;
    }
}

void MainWindow::fshowlogs(){
    if(isactive!=1){
        gbs[isactive]->hide();
        gbs[1]->show();
        isactive=1;
    }

}

void MainWindow::fshowdb(){
    if(isactive!=2){
        gbs[isactive]->hide();
        gbs[2]->show();
        isactive=2;
    }

}

void MainWindow::fshowfile(){
    if(isactive!=3){
        gbs[isactive]->hide();
        gbs[3]->show();
        isactive=3;
    }

}
