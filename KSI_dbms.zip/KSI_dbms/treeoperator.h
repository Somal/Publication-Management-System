#ifndef TREEOPERATOR_H
#define TREEOPERATOR_H

#include "node.h"

#include <QFile>
#include <QStack>

class TreeOperator
{
public:
    TreeOperator(QFile*file,qint64 rootlink,int node_size,int filepagesize);
    //work with disk memory
    Node noderead(qint64 link);
    void nodesave(Node*node);
    void nodesave(Node *node,qint64 nodelink);
    int baint(QByteArray*ba,int i);
    bool babool(QByteArray*ba,int i);
    qint64 baqint64(QByteArray*ba,int i);

    bool add(qint64 key,qint64 link);
//    bool deletekey(qint64 key);

    Node *root,*nd1,*nd2;
private:
    void spliting();
    int nodesize,filepagesize;
    Node findNode(qint64 key,QStack<qint64>*stack);
    QFile*f;
};

#endif // TREEOPERATOR_H
